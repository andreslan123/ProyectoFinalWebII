<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PagoSeeder extends Seeder
{
    public function run()
    {
        DB::table('pagos')->insert([

            [
                'pedido_id'=>1,
                'monto'=>450,
                'metodo'=>'QR'
            ],

            [
                'pedido_id'=>2,
                'monto'=>320,
                'metodo'=>'Tarjeta'
            ],

            [
                'pedido_id'=>3,
                'monto'=>170,
                'metodo'=>'Efectivo'
            ]

        ]);
    }
}