<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PromocionSeeder extends Seeder
{
    public function run()
    {
        DB::table('promociones')->insert([

            [
                'nombre'=>'Promo Frenos',
                'descuento'=>10,
                'fecha_inicio'=>'2026-06-01',
                'fecha_fin'=>'2026-06-30'
            ],

            [
                'nombre'=>'Promo Motores',
                'descuento'=>15,
                'fecha_inicio'=>'2026-06-01',
                'fecha_fin'=>'2026-07-15'
            ],

            [
                'nombre'=>'Promo Baterias',
                'descuento'=>20,
                'fecha_inicio'=>'2026-06-05',
                'fecha_fin'=>'2026-06-25'
            ]

        ]);
    }
}