<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EnvioSeeder extends Seeder
{
    public function run()
    {
        DB::table('envios')->insert([

            [
                'pedido_id'=>1,
                'direccion'=>'Zona Sur La Paz',
                'estado'=>'ENTREGADO'
            ],

            [
                'pedido_id'=>2,
                'direccion'=>'Santa Cruz',
                'estado'=>'EN CAMINO'
            ],

            [
                'pedido_id'=>3,
                'direccion'=>'Cochabamba',
                'estado'=>'PENDIENTE'
            ]

        ]);
    }
}