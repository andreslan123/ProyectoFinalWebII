<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run()
    {
        DB::table('users')->insert([

            [
                'rol_id' => 1, // admin
                'name' => 'Administrador',
                'email' => 'admin@gmail.com',
                'password' => Hash::make('12345678')
            ],

            [
                'rol_id' => 3, // vendedor
                'name' => 'Vendedor',
                'email' => 'vendedor@gmail.com',
                'password' => Hash::make('12345678')
            ],

            [
                'rol_id' => 2, // cliente
                'name' => 'Carlos Perez',
                'email' => 'carlos@gmail.com',
                'password' => Hash::make('12345678')
            ],

            [
                'rol_id' => 2, // cliente
                'name' => 'Juan Flores',
                'email' => 'juan@gmail.com',
                'password' => Hash::make('12345678')
            ],

            [
                'rol_id' => 2, // cliente
                'name' => 'Maria Lopez',
                'email' => 'maria@gmail.com',
                'password' => Hash::make('12345678')
            ]

        ]);
    }
}