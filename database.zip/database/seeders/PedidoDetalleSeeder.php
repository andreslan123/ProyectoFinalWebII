<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PedidoDetalleSeeder extends Seeder
{
    public function run()
    {
        DB::table('pedido_detalles')->insert([

            [
                'pedido_id'=>1,
                'producto_id'=>1,
                'cantidad'=>1,
                'precio_unitario'=>180,
                'subtotal'=>180
            ],

            [
                'pedido_id'=>1,
                'producto_id'=>2,
                'cantidad'=>1,
                'precio_unitario'=>270,
                'subtotal'=>270
            ],

            [
                'pedido_id'=>2,
                'producto_id'=>6,
                'cantidad'=>1,
                'precio_unitario'=>320,
                'subtotal'=>320
            ],

            [
                'pedido_id'=>3,
                'producto_id'=>5,
                'cantidad'=>1,
                'precio_unitario'=>170,
                'subtotal'=>170
            ]

        ]);
    }
}