<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductoImagenSeeder extends Seeder
{
    public function run()
    {
        DB::table('producto_imagenes')->insert([

            [
                'producto_id'=>1,
                'url'=>'piston.jpg'
            ],

            [
                'producto_id'=>2,
                'url'=>'culata.jpg'
            ],

            [
                'producto_id'=>3,
                'url'=>'pastillas.jpg'
            ],

            [
                'producto_id'=>4,
                'url'=>'disco.jpg'
            ],

            [
                'producto_id'=>5,
                'url'=>'amortiguador.jpg'
            ]

        ]);
    }
}