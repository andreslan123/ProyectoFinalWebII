<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MovimientoStockSeeder extends Seeder
{
    public function run()
    {
        DB::table('movimientos_stock')->insert([

            [
                'producto_id'=>1,
                'tipo'=>'ENTRADA',
                'cantidad'=>50
            ],

            [
                'producto_id'=>2,
                'tipo'=>'ENTRADA',
                'cantidad'=>40
            ],

            [
                'producto_id'=>3,
                'tipo'=>'SALIDA',
                'cantidad'=>5
            ],

            [
                'producto_id'=>4,
                'tipo'=>'SALIDA',
                'cantidad'=>3
            ]

        ]);
    }
}