<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PedidoSeeder extends Seeder
{
    public function run()
    {
        DB::table('pedidos')->insert([

            [
                'user_id'=>1,
                'fecha'=>'2026-06-01',
                'total'=>450
            ],

            [
                'user_id'=>2,
                'fecha'=>'2026-06-03',
                'total'=>320
            ],

            [
                'user_id'=>3,
                'fecha'=>'2026-06-05',
                'total'=>170
            ]

        ]);
    }
}