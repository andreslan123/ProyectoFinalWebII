<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StockProductoSeeder extends Seeder
{
    public function run()
    {
        DB::table('stock_productos')->insert([

            [
                'producto_id'=>1,
                'cantidad'=>50
            ],

            [
                'producto_id'=>2,
                'cantidad'=>40
            ],

            [
                'producto_id'=>3,
                'cantidad'=>35
            ],

            [
                'producto_id'=>4,
                'cantidad'=>60
            ],

            [
                'producto_id'=>5,
                'cantidad'=>25
            ]

        ]);
    }
}